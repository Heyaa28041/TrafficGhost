const API_BASE = "http://localhost:4000";

export class ApiError extends Error {
  status?: number;
  code?: string;

  constructor(message: string, status?: number, code?: string) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}

async function request(path: string, init?: RequestInit) {
  let response: Response;

  try {
    response = await fetch(`${API_BASE}${path}`, init);
  } catch {
    throw new ApiError(
      "The API could not be reached. Check that the local service is running.",
      undefined,
      "NETWORK_ERROR"
    );
  }

  if (!response.ok) {
    if (response.status === 404) {
      throw new ApiError(
        "The requested resource could not be found.",
        404,
        "RESOURCE_NOT_FOUND"
      );
    }

    if (response.status === 429) {
      throw new ApiError(
        "The API is rate limiting requests. Please try again.",
        429,
        "RATE_LIMITED"
      );
    }

    if (response.status >= 500) {
      throw new ApiError(
        "The backend service is currently unavailable. Database connection could not be established.",
        response.status,
        "DB_CONNECTION_ERROR"
      );
    }

    throw new ApiError(
      `The API returned an unexpected HTTP ${response.status} response.`,
      response.status,
      "API_ERROR"
    );
  }

  return response.json();
}

export async function getUsers() {
  return request("/api/users");
}

export async function getUser(id: number) {
  return request(`/api/users/${id}`);
}

// Intentionally incomplete for TrafficGhost developer-assistance testing:
// - no POST /api/users integration
// - no DELETE /api/users/:id integration
// - retry behavior is minimal
