import { useEffect, useState } from "react";
import { ApiError, getUsers } from "./api";

type User = {
  id: number;
  name: string;
  email: string;
  role: string;
};

type ErrorState = {
  title: string;
  message: string;
  status?: number;
  code: string;
};

export default function App() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<ErrorState | null>(null);

  async function loadUsers() {
    setLoading(true);
    setError(null);

    try {
      const data = await getUsers();
      setUsers(data.users ?? []);
    } catch (err) {
      const apiError = err as ApiError;

      if (apiError.status === 404) {
        setError({
          title: "Resource not found",
          message: "The requested user resource could not be found.",
          status: apiError.status,
          code: apiError.code ?? "RESOURCE_NOT_FOUND"
        });
      } else if (apiError.status === 429) {
        setError({
          title: "Too many requests",
          message: "The API is rate limiting requests. Please try again.",
          status: apiError.status,
          code: apiError.code ?? "RATE_LIMITED"
        });
      } else if (apiError.status && apiError.status >= 500) {
        setError({
          title: "Unable to load users",
          message:
            "The backend service is currently unavailable. Database connection could not be established.",
          status: apiError.status,
          code: apiError.code ?? "DB_CONNECTION_ERROR"
        });
      } else {
        setError({
          title: "Unable to connect",
          message:
            apiError.message || "The API could not be reached.",
          code: apiError.code ?? "NETWORK_ERROR"
        });
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadUsers();
  }, []);

  return (
    <main className="page">
      <header className="header">
        <div>
          <p className="eyebrow">Frontend integration demo</p>
          <h1>Users</h1>
          <p className="subtitle">
            A deliberately incomplete frontend for testing TrafficGhost developer assistance.
          </p>
        </div>
        <button onClick={loadUsers} disabled={loading}>
          {loading ? "Loading..." : "Refresh"}
        </button>
      </header>

      <section className="card">
        <div className="card-header">
          <div>
            <h2>User directory</h2>
            <p>Connected to the local API.</p>
          </div>
          <span className="badge">GET /api/users</span>
        </div>

        {loading && (
          <div className="state loading-state">
            <div className="spinner" />
            <div>
              <strong>Loading users...</strong>
              <p>Waiting for the API response.</p>
            </div>
          </div>
        )}

        {!loading && error && (
          <div className="error-panel" role="alert">
            <div className="error-content">
              <div className="error-label">API ERROR</div>
              <h2>{error.title}</h2>
              <p>{error.message}</p>
              <div className="error-meta">
                {error.status !== undefined && (
                  <span>HTTP {error.status}</span>
                )}
                <span>{error.code}</span>
              </div>
              <button className="retry" onClick={loadUsers}>
                Try Again
              </button>
            </div>
          </div>
        )}

        {!loading && !error && users.length > 0 && (
          <div className="users">
            {users.map((user) => (
              <article className="user" key={user.id}>
                <div className="avatar">{user.name.charAt(0)}</div>
                <div>
                  <strong>{user.name}</strong>
                  <p>{user.email}</p>
                </div>
                <span className="role">{user.role}</span>
              </article>
            ))}
          </div>
        )}

        {!loading && !error && users.length === 0 && (
          <div className="state">
            <strong>No users found.</strong>
            <p>The API returned an empty collection.</p>
          </div>
        )}
      </section>

      <section className="card checklist">
        <h2>Intentionally incomplete</h2>
        <ul>
          <li>POST /api/users is not integrated.</li>
          <li>DELETE /api/users/:id is not integrated.</li>
          <li>Retry behavior is minimal.</li>
          <li>TrafficGhost can be used to test backend failure scenarios.</li>
        </ul>
      </section>
    </main>
  );
}
